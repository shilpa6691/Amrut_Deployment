LOG_FILE_PATH = {'auth_logs_path':'/opt/siap/analytics/auth/logs/',
                 'auth_logs_name':'auth_log_file'}

SECRET_KEY ={"secret_key":"e19ed9473bb90bf9e878515baa1c1f4a21ac327b48224a068b3ba7b5df4d3ffa"}